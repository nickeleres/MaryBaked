(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Iron = Package['iron:core'].Iron;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron:location'] = {};

})();

//# sourceMappingURL=iron_location.js.map
